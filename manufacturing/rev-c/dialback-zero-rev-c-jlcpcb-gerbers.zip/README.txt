Dialback Zero Rev C: 130 x 80 mm, 2 layers, 1.6 mm FR-4, 35 um copper, ENIG.
All fabrication files are unchanged from the validated Rev C release.
Gerbers and Excellon drills use one absolute XY origin, in millimetres.
Gerber outline: X50..180 mm, Y-130..-50 mm. CPL preserves the same coordinates.
Use the separate JLCPCB BOM and CPL: 89 top factory placements, exact MPNs.
15 through-hole parts are user-soldered and omitted from the BOM/CPL.
H1-H8 are mechanical NPTH holes, not components for assembly.
USB-C J4 stays factory-fitted: six SMD contacts and four plated shell slots.
LS1 has two plated 2.40 x 1.60 mm horizontal routed slots, pitch10mm.
Required finished LS1 slots >=2.25 x1.45 mm; relative pitch9.80..10.20mm.
These are project acceptance limits, not a claim of fabrication tolerance.
The board is an electrically untested prototype. Verify selected parts and
placement orientation against pin1/polarity before releasing assembly.
